const help = (prefix) => { 
	return `
𝐑𝐮𝐥𝐞𝐬 - 𝐒𝐢𝐦𝐩𝐥𝐞 _*Xkyou-BOT*_
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
●⧐ *Spam : Auto Block!*
●⧐ *Beri Jeda 5detik Penggunaan!*
●⧐ *Bug/Error Harap Cht Owner!*
●⧐ *Harap Sabar Dengan Bug²nya!*
●⧐ *Gunakan Bot Sebaik-baiknya!*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
_*ListMenu*_

├ *${prefix}ownermenu*
├ *${prefix}adminmenu*
├ *${prefix}nsfwmenu*
├ *${prefix}funmenu*
├ *${prefix}mediamenu*
├ *${prefix}makermenu*
├ *${prefix}kerangmenu*
├ *${prefix}vipmenu*
├ *${prefix}animemenu*
├ *${prefix}othermenu*
└ *${prefix}listmenu*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
_*OthersMenu*_

├ *${prefix}request*
├ *${prefix}setprefix*
├ *${prefix}bugreport*
├ *${prefix}listblock*
├ *${prefix}iklan*
├ *${prefix}runtime*
├ *${prefix}info*
├ *${prefix}rules*
├ *${prefix}cekvip*
├ *${prefix}daftarvip*
├ *${prefix}donate*
├ *${prefix}ping*
├ *${prefix}owner*
├ *${prefix}tnc*
└ *${prefix}snk*
▬▭▬▭▬▭▬▭▬▭▬▭▬▭▬
*Special Thanks To*
_•MhankBarBar_
_•Rizky-BOT_
_•XP-TN_
_•AlphaKing_`

}
exports.help = help